# Hello, welcome to the Thousand.js library where you can explore the 2D world!

### First step, we'll show you how to use it. For more clarity and explanation, visit https://thousand.github.io/docs

## I'll show you some variables here.
| Key Worlds | Info                                      |
| ---------- | --------                                  |
| TH.               | Always used when adding an object. |
| TH.create.circle  | Let's create a circle.             |
| TH.create.cube    | Let's create a cube.               |

## Install

### Use ```npm install thousandjs``` to install the library.